import {defineStore} from 'pinia'
import {ref} from 'vue'

export const useDbStore = defineStore(
  'db',
  () => {
    const registerUserArr = ref([])
    const semesterInfoArr = ref([])
    const courseInfoMap = ref({})
    const colorStatistics = ref({})
    const activityInfoArr = ref({})
    const commentCourse = ref({})
    const sortOrderInfo = ref({})
    const trashCourse = ref({})
    const publicActs = ref([
      {
        id: 1,
        name: 'public act1 running',
        remainingCount: 3,
        description: 'running for health, 5km',
        schedule: [
          {
            week: 1,
            day: 'Mon',
            start: '8:00',
            end: '9:30',
            //   剩余座位
            remainTable: 1
          },
          {
            week: 6,
            day: 'Mon',
            start: '10:00',
            end: '11:30',
            //   剩余座位
            remainTable: 2
          },
          {
            week: 5,
            day: 'Mon',
            start: '14:00',
            end: '15:30',
            //   剩余座位
            remainTable: 1
          },
          {
            week: 4,
            day: 'Mon',
            start: '16:00',
            end: '17:30',
            //   剩余座位
            remainTable: 0
          },
          {
            week: 4,
            day: 'Mon',
            start: '16:00',
            end: '17:30',
            //   剩余座位
            remainTable: 0
          },
        ]
      },
      {
        id: 2,
        name: 'public act1 football',
        remainingCount: 8,
        description: 'running for health, 5km',
        schedule: [{
          week: 1,
          day: 'Thu',
          start: '8:00',
          end: '9:30',
          //   剩余座位
          remainTable: 5
        }, {
          week: 3,
          day: 'Wed',
          start: '9:30',
          end: '9:30',
          //   剩余座位
          remainTable: 2
        },
          {
            week: 3,
            day: 'Thu',
            start: '8:00',
            end: '9:30',
            //   剩余座位
            remainTable: 1
          },
          {
            week: 6,
            day: 'Wed',
            start: '16:00',
            end: '17:30',
            //   剩余座位
            remainTable: 3
          },
          {
            week: 2,
            day: 'Wed',
            start: '19:00',
            end: '20:30',
            //   剩余座位
            remainTable: 0
          },


        ]
      }
    ])
    return {
      commentCourse,
      trashCourse,
      registerUserArr,
      sortOrderInfo,
      semesterInfoArr,
      courseInfoMap,
      colorStatistics,
      activityInfoArr,
      publicActs
    }
  },
  {
    persist: true
  }
)