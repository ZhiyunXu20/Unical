// 学期开始结束事件颜色
export const termDurColorStart = '#DCA151'
export const termDurColorEnd = '#6c460d'