// 是否合法的数值
export const isValidVal = (val) => {
  return val != null
}

// 判断是否为null
export const isNull = (val) => {
  return val == null
}

export const isUndefined = (val) => {
  return val === undefined
}
