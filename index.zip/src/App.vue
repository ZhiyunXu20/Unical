<script setup></script>
<template>
  <div class="flex justify-center">
    <Calendar />
  </div>
</template>
<style>
html,
body {
  margin: 0;
  padding: 0;
  height: 100%;
}
</style>