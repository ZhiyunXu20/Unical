<script setup>

</script>

<template>
  <img src="@/assets/logo.png" class="w-200px mx-auto"/>
</template>

<style scoped>

</style>