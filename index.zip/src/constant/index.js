export * from './mockData.js'

export const grayColor = '#C2C1C0FF'
